# *This activity has been created as part of the 42 curriculum by `bmanalla` and `jhima`.*

# A-Maze-ing

> A configurable maze generator written in **Python 3** that creates valid random mazes, exports them using a hexadecimal wall representation, computes the shortest path, and provides a visual representation of the generated maze.

---
# License

This project is distributed under the MIT License.

See `LICENSE.md` for the complete license text.

# Description

**A-Maze-ing** is a maze generation project developed as part of the **42 Curriculum**.

The objective of the project is to design and implement a complete maze generation system capable of:

* Generating random, fully connected mazes
* Supporting reproducible generation through random seeds
* Producing both perfect and non-perfect mazes
* Exporting mazes in a hexadecimal wall encoding format
* Computing the shortest path between the entrance and exit
* Rendering the maze visually
* Providing a reusable Python package for future projects

The project combines concepts from:

* Graph Theory
* Recursive Algorithms
* Randomized Algorithms
* Pathfinding
* Software Engineering
* Object-Oriented Programming

---

# Features

* Random maze generation
* Configurable maze dimensions
* Perfect maze generation (single unique solution)
* Optional random seed for reproducibility
* Automatic shortest path computation
* Hexadecimal wall encoding
* ASCII or graphical maze rendering
* Interactive visualization
* Reusable `MazeGenerator` module
* Error handling for invalid configurations
* Modular architecture

---

#  Technologies

* Python 3.10+
* Object-Oriented Programming
* Type Hints
* Flake8
* MyPy
* Makefile
* Git

---

# Project Structure

```text
├── a_maze_ing.py
├── config_parser.py
├── config.txt
├── Makefile
├── MazeGenerator.py
├── menu.py
├── photo
│   ├── image-1.png
│   ├── image-2.png
│   ├── image-3.png
│   ├── image-4.png
│   ├── image-5.png
│   └── image.png
├── pyproject.toml
└── Readme.md
```

---

# Installation

Clone the repository:

```bash
git clone https://github.com/<username>/A-Maze-ing.git
cd A-Maze-ing
```

Install dependencies:

```bash
make install
```

or

```bash
pip install -r requirements.txt
```

---

# Running the Project

Execute:

```bash
python3 a_maze_ing.py config.txt
```

or

```bash
make run
```

---

# Configuration File

The maze is configured through a text file using the following format:

```text
WIDTH=20
HEIGHT=15

ENTRY=0,0
EXIT=19,14

OUTPUT_FILE=maze.txt

PERFECT=True

SEED=42
```

## Parameters

| Key               | Description                             |
| ----------------- | --------------------------------------- |
| WIDTH             | Maze width                              |
| HEIGHT            | Maze height                             |
| ENTRY             | Entrance coordinates                    |
| EXIT              | Exit coordinates                        |
| OUTPUT_FILE       | Output filename                         |
| PERFECT           | Generate a perfect maze                 |
| SEED *(optional)* | Random seed for reproducible generation |

---

# Maze Generation Algorithm

**Algorithm Used: Recursive Backtracker (iterative Depth-First Search)**

The maze is carved out of a fully-walled grid using an iterative depth-first search with an explicit stack:

1. Start at the top-left cell, mark it visited, and push it onto the stack.
2. While the stack is not empty, look at the cell on top of the stack:
   * If it has any unvisited neighbors, pick one at random, remove the wall between the two cells, mark the neighbor visited, and push it onto the stack.
   * If it has no unvisited neighbors, pop it off the stack (backtrack).
3. The maze is complete once the stack empties and every reachable cell has been visited.

For **non-perfect** mazes, an extra pass randomly removes a small percentage of the remaining walls after generation, introducing loops so more than one path exists between the entrance and exit.

Once the maze is carved, the shortest route between entrance and exit is computed with a **Breadth-First Search (BFS)**, which guarantees the shortest path in an unweighted grid.

Example:

```text
Stack: [(0,0)]
(0,0) has unvisited neighbors E, S -> pick E -> wall removed -> push (1,0)
Stack: [(0,0), (1,0)]
(1,0) has unvisited neighbor S -> pick S -> wall removed -> push (1,1)
Stack: [(0,0), (1,0), (1,1)]
(1,1) has no unvisited neighbors -> pop -> backtrack to (1,0)
...continues until the stack is empty and every cell has been visited.
```

### Why this algorithm?

It was selected because it:

* Generates perfect mazes naturally
* Produces long and interesting corridors
* Is simple to implement
* Has linear time complexity
* Requires minimal memory

---

# Maze Representation

Each maze cell stores four walls:

* North
* East
* South
* West

The walls are encoded using one hexadecimal digit.

Example:

| Binary | Hex | Meaning                   |
| ------ | --- | ------------------------- |
| 0000   | 0   | No walls                  |
| 0011   | 3   | North & East walls closed |
| 1010   | A   | East & West walls closed  |
| 1111   | F   | All walls closed          |

---

# Shortest Path

After generating the maze, the program computes the shortest valid route between the entrance and exit.

The resulting path is stored using movement directions:

```text
N
E
S
W
```

The visual renderer can optionally display this solution.

---

#  Visualization

The maze can be displayed using:

* ASCII rendering in the terminal

After the maze is drawn, an interactive menu is shown:

```text
1) Generate a new maze
2) Show/Hide the shortest path
3) Change wall color
4) Exit
```

* **Generate a new maze** re-runs generation with the same width, height, entry, and exit, producing a fresh random layout.
* **Show/Hide the shortest path** toggles the solution overlay on the existing maze without regenerating it.
* **Change wall color** lets you pick from a list of ANSI colors (red, green, yellow, blue, magenta, cyan, white) for the walls.

---

#  Reusable Module

One objective of the project is code reusability.

The reusable package exposes a `MazeGenerator` class that can be imported into other Python projects.


The module provides access to:

* Generated maze structure
* Entrance
* Exit
* Shortest solution
* Configuration options

---

# Output Format

The generated maze is exported as:

```text
A9C3F...
...

ENTRY=0,0
EXIT=19,14
EESSWWNN...
```

The file contains:

* Maze hexadecimal encoding
* Entry coordinates
* Exit coordinates
* Shortest path

---

#  Makefile Commands
 
| Command           | Description                              |
|-------------------|------------------------------------------|
| `make install`    | Create venv, install package and linters |
| `make run`        | Run the program with default config      |
| `make debug`      | Run in pdb debug mode                    |
| `make lint`       | Run flake8 + mypy with standard flags    |
| `make lint-strict`| Run mypy with `--strict`                 |
| `make clean`      | Remove `__pycache__`, `.mypy_cache`, venv|
 

---


## How It Looks
 
### Terminal Rendering
 
The maze is drawn directly in the terminal using ASCII block characters. Walls are rendered as solid blocks, open corridors as spaces. Entry is marked in **magenta**, exit in **red**.

## Default View

![Maze without 42 pattern](photo/image.png)
*Basic maze rendering — no 42 pattern visible*

### With 42 Pattern

![Maze with 42 pattern](photo/image-1.png)
*The "42" shape appears in the center, formed by fully closed cells*

### Shortest Path

![Maze with path hidden](photo/image-2.png)
*Path hidden — default state after generation*

### Color Customization

![Color picker for 42 wall](photo/image-3.png)
*Menu prompt to choose a color for the 42 pattern walls*

![42 wall color changed](photo/image-4.png)
*42 pattern rendered in the selected color*

![Wall color changed](photo/image-5.png)
*Main maze walls with a different color applied*

#  Testing

The project has been tested with:

* Small mazes
* Large mazes
* Perfect mazes
* Invalid configuration files
* Edge-case dimensions
* Reproducible seeds

---

## Project Planning

The project followed an iterative development process:

1. Requirements analysis
2. Maze representation
3. Generation algorithm
4. Pathfinding
5. Visualization
6. Testing
7. Documentation

---

## What Worked Well

* Modular architecture
* Separation of responsibilities
* Reusable generator module
* Configuration-driven design

---

## Project Management Tools

* Git
* GitHub
* VS Code / PyCharm
* Python Virtual Environment

# Team & Project Management

## Team Members

### bmanalla

Primary responsibilities:

- Overall project architecture
- Maze generation algorithm implementation
- Configuration parser
- Hexadecimal export format
- Testing and debugging
- Documentation and repository organization

### jhima

Primary responsibilities:

- Maze visualization
- Interactive terminal menu
- Shortest path visualization
- User interface improvements
- Testing and feature validation
- Documentation review

Although responsibilities were divided, all major implementation decisions were discussed together, and both members participated in reviewing and testing each other's work before integrating changes.

---

## Initial Planning

At the beginning of the project, we divided the work into several milestones:

1. Understand the project requirements.
2. Design the maze data structure.
3. Implement maze generation.
4. Implement configuration parsing.
5. Implement maze export.
6. Implement shortest path computation.
7. Develop the terminal visualization.
8. Test edge cases.
9. Prepare reusable package.
10. Write project documentation.

The initial goal was to first complete a functional maze generator and then progressively add visualization and usability improvements.

---

## How the Planning Evolved

As development progressed, we realized that several components depended heavily on one another.

For example:

- The visualization required changes to the maze representation.
- Supporting reproducible generation using random seeds required adjustments to the generation pipeline.
- Implementing both perfect and non-perfect maze generation introduced additional validation logic.
- The interactive terminal menu was expanded after the core functionality was completed to improve usability.

Rather than following the original plan strictly, development became iterative. Features were implemented, tested, refined, and sometimes redesigned before moving on to the next milestone.

Regular testing throughout development helped identify design issues early and reduced the amount of rework required later.

---

## What Worked Well

Several aspects of the project were particularly successful:

- Clear modular architecture.
- Separation between maze generation, visualization, configuration parsing, and export.
- Reusable `MazeGenerator` class.
- Configuration-driven design.
- Consistent use of type hints and static analysis.
- Incremental testing after each completed feature.
- Good collaboration during debugging and code reviews.

---

## What Could Be Improved

If the project were developed again, several improvements could be made:

- Add automated unit tests using `pytest`.
- Support multiple maze generation algorithms (Prim's, Kruskal's, Wilson's, etc.).
- Provide graphical rendering in addition to ASCII output.
- Improve customization options for colors and visualization.
- Benchmark maze generation performance for larger mazes.
- Add continuous integration (CI) using GitHub Actions.
- Expand the reusable package documentation with additional examples.

---

## Development Tools

The following tools were used during development:

### Version Control

- Git
- GitHub

### Development Environment

- Visual Studio Code
- Python Virtual Environment (`venv`)

### Code Quality

- Flake8
- MyPy

### Debugging

- Python Debugger (`pdb`)
- Print-based debugging during early development

### Project Management

- GitHub Issues (task tracking)
- Feature branches with pull-request style reviews before merging

### Documentation

- Markdown
- Python Docstrings (PEP 257)

### Artificial Intelligence

Artificial Intelligence tools were used as development assistants for:

- Reviewing algorithms
- Explaining Python concepts
- Debugging assistance
- Documentation drafting
- README organization
- Refactoring suggestions

# Resources

## Documentation

* Python Documentation
* PEP 8 Style Guide
* Flake8
* MyPy Documentation

## Algorithms

* Recursive Backtracker
* Breadth-First Search (BFS)
* Depth-First Search (DFS)

## AI Usage

Artificial Intelligence tools were used to assist with:

* Documentation drafting
* Code review
* Debugging assistance
* Refactoring suggestions
* README structure improvements

All generated content was reviewed, tested, and adapted before inclusion in the final project.

---

